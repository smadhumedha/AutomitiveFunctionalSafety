The following files were generated for 'virtex4_dmem' in directory 
/home/pitchu/Projects/verilog/openMSP430/core/synthesis/xilinx/src/coregen/

virtex4_dmem_flist.txt:
   Text file listing all of the output files produced when a customized
   core was generated in the CORE Generator.

blk_mem_gen_ds512.pdf:
   Please see the core data sheet.

virtex4_dmem.gise:
   ISE Project Navigator support file. This is a generated file and should
   not be edited directly.

virtex4_dmem.ise:
   ISE Project Navigator support file. This is a generated file and should
   not be edited directly.

virtex4_dmem.ngc:
   Binary Xilinx implementation netlist file containing the information
   required to implement the module in a Xilinx (R) FPGA.

virtex4_dmem.v:
   Verilog wrapper file provided to support functional simulation.
   This file contains simulation model customization data that is
   passed to a parameterized simulation model for the core.

virtex4_dmem.veo:
   VEO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a Verilog design.

virtex4_dmem.xco:
   CORE Generator input file containing the parameters used to
   regenerate a core.

virtex4_dmem.xise:
   ISE Project Navigator support file. This is a generated file and should
   not be edited directly.

virtex4_dmem_readme.txt:
   Text file indicating the files generated and how they are used.

virtex4_dmem_xmdf.tcl:
   ISE Project Navigator interface file. ISE uses this file to determine
   how the files output by CORE Generator for the core can be integrated
   into your ISE project.


Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

