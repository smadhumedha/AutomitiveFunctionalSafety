void cprintf(const char *, ...);
