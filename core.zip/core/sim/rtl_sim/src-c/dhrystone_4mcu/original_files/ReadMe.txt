Adapted Dhrystone source files:

  dhry.h
  dhry21a.c
  dhry21b.c
  timers_b.c
  estubs.c

ZDS II 4.8.0 project file:

  dhrystone.pro

Programmer's Notepad project file:

  dhrystone.pnproj

AVR-GCC Makefile:

  Makefile

This file:

  ReadMe.txt
