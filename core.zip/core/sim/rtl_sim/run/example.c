#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
	time_t tms,tme;
	tms=time(NULL);
	system("./run");
	tme=time(NULL);
	printf("%f\n",difftime(tme,tms));
	//printf("%d",clock(tm));
	return 0;
}
