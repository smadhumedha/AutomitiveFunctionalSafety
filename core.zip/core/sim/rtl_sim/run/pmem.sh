

pmemsize=4096
dmemsize=1024
persize=512
